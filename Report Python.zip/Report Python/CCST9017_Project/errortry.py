import numpy as np
import matplotlib.pyplot as plt

# Parameters for the circle
center = 1 + 1j
radius = np.sqrt(2)
t = np.linspace(0, 2 * np.pi, 500)

# Points on the circle
z = center + radius * np.exp(1j * t)

# Compute 1/conjugate(z)
z_bar = np.conj(z)
f_z = 1 / z_bar

# Plot the original circle and the transformed points
plt.figure(figsize=(8, 8))
plt.plot(z.real, z.imag, label="Circle: z", color="blue")  # Original circle
plt.scatter(f_z.real, f_z.imag, s=1, color="red", label="1/z̄")  # Transformed points

# Formatting
plt.axhline(0, color='black', linewidth=0.5, linestyle="--")
plt.axvline(0, color='black', linewidth=0.5, linestyle="--")
plt.gca().set_aspect('equal', adjustable='datalim')
plt.title("Transformation: 1/z̄")
plt.xlabel("Real")
plt.ylabel("Imaginary")
plt.legend()
plt.grid(True)
plt.show()
