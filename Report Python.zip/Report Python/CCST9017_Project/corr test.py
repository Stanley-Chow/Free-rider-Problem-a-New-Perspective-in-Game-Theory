import pandas
dataset={
    'k' : [1,2,2,3],
    'd' : [3,4,5,6]
}
df = pandas.DataFrame(dataset)
print(df)
a=df.corr()
print(a)